from service.config_service import get_learning_cfg

get_learning_cfg('match_goals')