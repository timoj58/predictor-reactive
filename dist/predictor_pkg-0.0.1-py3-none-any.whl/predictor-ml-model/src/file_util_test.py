from util.file_utils import write_csv

write_csv("/home/timmy/testing.csv",
          [
              {
                  "home": "8be8ee1d-c818-4b76-a71f-c9279ad90453",
                  "away": "248c87bd-109f-49a9-962c-dd43d0e0b654",
                  "outcome": "draw",
                  "goals": 0
              },
              {
                  "home": "8be8ee1d-c818-4b76-a71f-c9279ad90453",
                  "away": "248c87bd-109f-49a9-962c-dd43d0e0b654",
                  "outcome": "draw",
                  "goals": 0
              }
          ])