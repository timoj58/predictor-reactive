# predictor-reactive
mono-repo for conversion of old services

Machine learning micro-service setup, fully reactive, leveraging tensorflow

data scraper (espn)
betting scraper (paddypower, betway)
